# cs-470-reversi-python-client

A Python 3 client for the BYU CS 470 Reversi lab. All that you need to change for your project is the `make_move` function in the reversi_bot.py script. See comment there for information on useful functionality. 

To run, enter directory where this code is located and type `python reversi_python_client.py localhost 1` if you want this running on localhost and for it to be first player. You can do 2 for second player or specify a different host as well.

## PULL REQUESTS ARE WELCOME

![Reversi Board Image](https://upload.wikimedia.org/wikipedia/commons/a/ae/Othello_%28Reversi%29_board.jpg)
